from django.shortcuts import render
from django.contrib.auth import login
# Create your views here.


def login_student_views(request):
    if request.method=='GET':
        if request.method=='POST':
                t1='Roll Number'
                t2='Student Name'
                t3='Course Name'
                t4='Batch'
                d1={1:'t1',2:'t2',3:'t3',4:'t4'}
                resp=render(request,'CMS/login.html',context=d1)
                return resp
    else:
                print("Data Not Found")                    
def login_teacher_views(request):
    if request.method=='GET':
        if request.method=='POST':
                t1='Teacher ID'
                t2='Teacher Name'
                t3='Department Name'
                t4='Subjects'
                d1={a:'t1',b:'t2',c:'t3',d:'t4'}
                resp=render(request,'CMS/login.html',context=d1)
                return resp
    else:
                print("Data Not Found") 
                
def login_library_views(request):
    if request.method=='GET':
        if request.method=='POST':
                t1='Department'
                t2='Name Of Book'
                t3='Library ID'
                t4='Subjects'
                d1={x:'t1',y:'t2',z:'t3',s:'t4'}
                resp=render(request,'CMS/login.html',context=d1)
                return resp
    else:
                print("Data Not Found")   