from django.urls import path
from .views import *
#Base URL => http://127.0.0.1:8000/api/

urlpatterns = [
    
    path('student/',login_student_views),
    path('teacher/',login_teacher_views),
    path('library/',login_library_views),
]