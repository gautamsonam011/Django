from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from Restapi.serializer import serializers
# Create your views here.
@api_view(http_method_names=['GET','POST','PUT','PATCH','DELETE'])
def first_api_view(request):
    msg="This is my first api"
    msg=896870
    msg=('Python',987,8.90)
    msg=['Hello',979,86.54,-8457]
    msg={"th":675,"tag":"Hello",1:678}
    resp=Response(data=msg)
    return resp
@api_view(['GET','POST','PUT','PATCH','DELETE'])
def Get_view(request,sid):
    stu=Student.ojects.get(id=sid)
    stu_serializer=StudentSerializer(stu)
    resp=Response(data=stu_serializer)
    return resp