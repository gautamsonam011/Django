from django.db import models

# Create your models here.
class Student(models.Model):
        name=models.CharField(max_length=50,null=False,blank=False)
        age=models.IntegerField()
        mobileno=models.CharField(max_length=20)
        created_date=models.DateTimeField(auto_now_add=True)
        last_updated_date=models.DateTimeField(auto_now=True)
        def _str_(self):
            return self.name
