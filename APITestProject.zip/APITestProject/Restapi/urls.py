from django.urls import path
from .views import *
#Base URL => http://127.0.0.1:8000/api/

urlpatterns = [
    
    path('first/',first_api_view),
    path('getstu/<int:sid>/',Get_view),
    
]