from rest_framework import serializers
from Restapi.models import Student
class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        fields=['name','age','mobileno']