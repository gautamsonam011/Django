from django.urls import path
from .views import *

#Base URL =>> http://127.0.0.1:8000/cms/

urlpatterns = [
    path('home/',view_school_home),
]