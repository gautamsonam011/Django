from django.db import models

# Create your models here.

class School(models.Model):
    # pincode=models.IntegerField() # No need to take id field because id automatically created by Django.
    name=models.CharField(max_length=50)
    year=models.IntegerField()
    mobileno=models.CharField(max_length=15)
    address=models.CharField(max_length=100)
    def _str_(self): #Mandotory
        return self.name
