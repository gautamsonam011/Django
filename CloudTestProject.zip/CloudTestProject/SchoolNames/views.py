from django.shortcuts import render
from ast import Delete
from django.http import HttpResponse
from SchoolNames.models import School

# Create your views here.
def view_school_home(request):
    if request.method=='GET':
        resp=render(request,'SchoolNames/School.html')
        return resp
    elif request.method=='POST':
        if 'btnadd' in request.POST: #For insert data in database
            sch=School()
            sch.name=request.POST.get('txtname','NA')
            sch.year=request.POST.get('txtage','NA')
            sch.mobileno=request.POST.get('txtmobile','NA')
            sch.address=request.POST.get('txtaddress','NA')
            sch.save()
            resp=HttpResponse("<h1>Customer Added SuccessFully with ID"+str(sch.id)+"!</h1>")
            return resp
        elif 'btnsearch' in request.POST: # Search data from database
            pincode=int(request.POST.get('txtid',0))
            sch=School.objects.get(id=pincode)
            d1={'sch':sch}
            resp=render(request,'SchoolNames/School.html',context=d1)
            return resp
        elif 'btnupdate' in request.POST: # Update data or modify data in database
            sch=School()
            sch.id=int(request.POST.get('txtid',0))
            if School.objects.get(id=sch.id):
                sch.name=request.POST.get('txtname','NA')
                sch.year=request.POST.get('txtage','NA')
                sch.mobileno=request.POST.get('txtmobile','NA')
                sch.address=request.POST.get('txtaddress','NA')
                sch.save()
                resp=HttpResponse("<h1>Customer Updated SuccessFully with ID"+str(sch.id)+"!</h1>")
                return resp
        elif 'btndelete' in request.POST: # delete data from the table
            sch = School()
            sch.id=int(request.POST.get('txtid',0))

            School.objects.filter(id=sch.id).delete()
            resp=HttpResponse("<h1>Customer Deleted SuccessFully with ID"+str(sch.id)+"!</h1>")
            return resp
        elif 'btnshow' in request.POST: #All data show in table formate
            all_sch=School.objects.all()
            d1={'school':all_sch}
            resp=render(request,'SchoolNames/School.html',context=d1)
            return resp
        
        
    elif 'btnsearch' in request.POST:
        scho = School()
        scho.id=int(request.POST.get('txtid',0))
        all_scho=School.objects.filter(postalcode=pincode).values()
        d1={'school':all_scho}
        resp=render(request,'SchoolNames/School.html',context=d1)
        return resp
        # scho = School()
        # scho = School.objects.filter(pincode='postalcode').values()
        # d1 = {'my':scho}
        # resp = render(request,'SchoolNames/School.html',context=d1)
        # return resp
        