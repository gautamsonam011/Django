from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.response import Response
from rest_framework.decorators import api_view
from SMS.models import SearchSchoolName
from .serializers import SchoolModelSerializer

# Create your views here.
@api_view(http_method_names=['GET','POST','PUT','PATCH'])
def my_first_api(request):
    resp=Response(data="This is my First API")
    return resp

@api_view(['GET','POST','PATCH','PUT'])
def my_second_api(request):
    schoolnames = ['K.V.M Public School','Little Flora Dale School','Tarawati Memorial Public School']
    resp = Response(data = schoolnames)
    return resp

@api_view(['GET','POST','PUT','PATCH'])
def my_school_home_page(request, sid):
    sch = SearchSchoolName.objects.get(id = sid)
    sch_serializer = SchoolModelSerializer(sch)
    resp = Response(data = sch_serializer.data)
    return resp


@api_view(http_method_names=['GET','POST','PUT','PATCH'])
def my_other_page(request, sid):
    if request.method=='GET':
        resp=render(request,'SMS/index.html')
        return resp
    elif request.method=='POST':
        if 'btnadd' in request.POST:
            sch=SearchSchoolName()
            sch_ser = SchoolModelSerializer(sch)
            sch_ser.name=request.POST.get('txtname','NA')
            sch_ser.age=request.POST.get('txtage','NA')
            sch_ser.mobileno=request.POST.get('txtmobile','NA')
            sch_ser.address=request.POST.get('txtaddress','NA')
            sch_ser.save()
            resp=Response(data = sch_ser)
            return resp
        elif 'btnsearch' in request.POST:
            sid=int(request.POST.get('txtid',0))
            sch=SearchSchoolName.objects.get(id=sid)
            sch_ser = SchoolModelSerializer(sch)
            d1={'sch':sch_ser}
            resp=render(request,'SMS/index.html',context=d1)
            return resp
        elif 'btnupdate' in request.POST:
            sch=SearchSchoolName()
            sch_ser = SchoolModelSerializer(sch)
            sch.id=int(request.POST.get('txtid',0))
            if sch_ser.objects.get(id=sch_ser.id):
                sch_ser.name=request.POST.get('txtname','NA')
                sch_ser.year=request.POST.get('txtage','NA')
                sch_ser.mobileno=request.POST.get('txtmobile','NA')
                sch_ser.address=request.POST.get('txtaddress','NA')
                sch_ser.save()
                resp=Response(data = sch_ser)
                return resp
        elif 'btndelete' in request.POST:
            sch_id=int(request.POST.get('txtid',0))
            SchoolModelSerializer.objects.filter(id=sch_id).delete()
            resp=Response(data = sch_ser)
            return resp
        elif 'btnshow' in request.POST:
            all_sch=SchoolModelSerializer.objects.all()
            d1={'school':all_sch}
            resp=render(request,'SMS/index.html',context=d1)
            return resp