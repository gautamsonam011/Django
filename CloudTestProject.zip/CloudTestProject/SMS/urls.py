from django.urls import path
from .views import *

# Base URL => http://127.0.0.1:8000/sms/

urlpatterns = [
    path('first/',my_first_api),
    path('second/',my_second_api),
    path('index/<int:sid>/',my_school_home_page),
    path('main/<int:sid>/',my_other_page)
]
