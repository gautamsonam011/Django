from rest_framework.serializers import ModelSerializer
from SMS.models import SearchSchoolName

class SchoolModelSerializer(ModelSerializer):
    class Meta:
        model = SearchSchoolName
        fields = ['id','schoolname','year','mobileno','address','pincode']
    