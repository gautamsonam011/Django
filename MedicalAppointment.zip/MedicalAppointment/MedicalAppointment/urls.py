from django.contrib import admin
from django.urls import path
from Appointment import views
from django.contrib.auth.views import LoginView,LogoutView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home_view,name='index'),
    
    # Patient register and login
    
    path('patientlogin', LoginView.as_view(template_name='Appointment/login.html')),
     path('patientsignup', views.patient_signup_view),
    path('logout', LogoutView.as_view(template_name='Appointment/index.html'),name='logout'),
    path('patient-dashboard', views.patient_dashboard_view,name='patient-dashboard'),
    
    path('afterlogin', views.afterlogin_view,name='afterlogin'),
    
    path('redirect/', views.login_redirect, name='login_redirect'),
    
    # admin register and login 
    
    path('adminsignup', views.admin_signup_view),
    path('adminlogin', LoginView.as_view(template_name='Appointment/admin-login.html')),
    path('admin-dashboard', views.admin_dashboard_view,name='admin-dashboard'),
]
