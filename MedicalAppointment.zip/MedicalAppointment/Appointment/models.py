from django.db import models
from django.contrib.auth.models import User

class Patient(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic= models.ImageField(upload_to='profile_pic/PatientProfilePic/',null=True,blank=True)
    address = models.CharField(max_length=40 , default=False)
    mobile = models.CharField(max_length=20,null=False, default='Mobile number')
    symptoms = models.CharField(max_length=100,null=False,default='Symptoms')
    admitDate=models.DateField(auto_now=True)
    status=models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return self.user.first_name+" ("+self.symptoms+")"
    
class Doctor(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=50,null=False,blank=False)
    spacilist=models.CharField(max_length=500,null=False,blank=False)
    degree=models.CharField(max_length=500,null=False,blank=False)
    mobile = models.IntegerField()    
    hospitalName=models.CharField(max_length=500,null=False,blank=False)
    address=models.CharField(max_length=500,null=False,blank=False, default=False)
    weekday=models.CharField(max_length=500,null=False,blank=False) 
    profile_pic =models.ImageField()
    created_date=models.DateTimeField(auto_now_add=True)
    last_updated_date=models.DateTimeField(auto_now=True)
    status=models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
  



class Patient_detail(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    patientName = models.CharField(max_length=500,null=False,blank=False)
    gender = models.CharField(max_length=500,null=False,blank=False)
    dateofbirth = models.IntegerField()
    mobileNo = models.IntegerField()
    disease = models.CharField(max_length=500,null=False,blank=False)
    desc = models.CharField(max_length=500,null=False,blank=False)
    profile_pic= models.ImageField(upload_to='profile_pic/PatientProfilePic/',null=True,blank=True)
    slots = models.TimeField()
    assignedDoctorId = models.PositiveIntegerField(null=True)
    status=models.BooleanField(default=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return self.user.first_name+" ("+self.disease+")"
    
class Appointment(models.Model):
    patientId=models.PositiveIntegerField(null=True)
    doctorId=models.PositiveIntegerField(null=True)
    patientName=models.CharField(max_length=40,null=True)
    doctorName=models.CharField(max_length=40,null=True)
    appointmentDate=models.DateField(auto_now=True)
    description=models.TextField(max_length=500)
    status=models.BooleanField(default=False)


class my_appointment(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    patientName = models.CharField(max_length=500,null=False,blank=False)
    gender = models.CharField(max_length=500,null=False,blank=False)
    mobileNo = models.IntegerField()
    age = models.DateField()
    disease = models.CharField(max_length=500,null=False,blank=False)
    time = models.TimeField()
    date = models.DateField()
    doctorName = models.CharField(max_length=500,null=False,blank=False)
    hospitalName = models.CharField(max_length=500,null=False,blank=False)
    address=models.CharField(max_length=500,null=False,blank=False)

    def __str__(self):
        return self.patientName
    

class time_slots(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    in_time = models.TimeField()
    out_time = models.TimeField()
    time_slots = models.TimeField()
    
class clinic_area(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    clinic_name = models.CharField(max_length=500)
    area_name = models.CharField(max_length=500)
    admitDate=models.DateField(auto_now=True)
    status=models.BooleanField(default=False)
    
    
    