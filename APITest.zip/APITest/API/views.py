from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
# Create your views here.

@api_view(http_method_names=['GET','POST'])
def view_first_api(request):
    resp = Response(data= "This is my first api")
    return resp

# @api_view(['GET'])
# def view_getstudentdetail(request,sid):
#     stu=Student.objects.get(id=sid)
#     stu_serialzer=StudentSerializer(stu)
#     resp=Response(data=stu_serialzer.data)
#     return resp
