from django.shortcuts import *
from django.http import HttpResponse

def hellop(request):
    resp = HttpResponse("<h1>Hello World!!</h1>")
    return resp