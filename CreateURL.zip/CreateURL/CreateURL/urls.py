"""CreateURL URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.shortcuts import render
from django.http import HttpResponse


def calc_func(request):
    if request.method == "GET":
        resp = render(request,"calculator.html")
        return resp
    elif request.method == "POST":
        a = int(request.POST.get('n1',0))
        b = int(request.POST.get('n2',0))
        if 'btnsum' in request.POST:
            res = a+b
            d1 = {'a':a,'b':b,'res':res}
            resp = render(request,"calculator.html", context=d1)
            return resp
        elif 'btnsub' in request.POST:
            res = a-b
            d1 = {'a':a,'b':b,'res':res}
            resp = render(request,"calculator.html", context=d1)
            return resp
        elif 'btnmul' in request.POST:
            res = a*b
            d1 = {'a':a,'b':b,'res':res}
            resp = render(request,"calculator.html", context=d1)
            return resp
        elif 'btndiv' in request.POST:
            res = a/b
            d1 = {'a':a,'b':b,'res':res}
            resp = render(request,"calculator.html", context=d1)
            return resp
 
def get_Numeric_Number(request):
    list_button = ['t1','t2','t3','t4','t5','t6','t7','t8','t9','t0']
    for b in list_button:
        if b in request.POST:
            return b[1] 
    return '-1'           
def btn_cal(request):
    # if request.method == "GET":
    #     resp = render(request,"calcbtn.html")
    #     return resp
    # elif request.method == "POST":
    #     msg = request.POST.get('res',0)
    #     check_no = get_Numeric_Number(request)
    #     if (check_no != -1):
    #         msg =msg+check_no
    #         d1 = {'msg':msg}
    #         resp = render(request,'calcbtn.html',context=d1)
    #         return resp
    if request.method=='GET':
        resp=render(request,'calcbtn.html')
        return resp
    elif request.method=='POST':
        msg=request.POST.get('res','')
        check_no=get_Numeric_Number(request)
        if(check_no!='-1'): # '8'!='-1'  true
            msg=msg+check_no # msg=''+'8' msg='8'
            d1={'msg':msg}
            resp=render(request,'calcbtn.html',context=d1)
            return resp

        
     
# path(urlMapping,functionName)
urlpatterns = [
    path('admin/', admin.site.urls),
    path('cal/',calc_func),
    path('btncal/',btn_cal),
    path('cms/',include('CMS.urls')),
    path('sms/',include('SMS.urls')),
    
]
