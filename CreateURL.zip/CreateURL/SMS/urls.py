from django.urls import path
from .views import *
#Base URL =>> http://127.0.0.1:8000/sms/

urlpatterns = [
    path('payment/',view_paymentDetails),
    path('course/',get_course_wise_student_details),
    path('stufrm/',view_student),
    path('paydetails/',view_paymentdetails),

]
