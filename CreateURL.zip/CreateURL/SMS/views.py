from django.shortcuts import render
from django.http import HttpResponse
from SMS.models import *
from SMS.forms import *
# Create your views here.

# one to many relationship 

def view_paymentDetails(request):
    if request.method == 'GET':
        resp = render(request,'SMS/index.html')
        return resp
    elif request.method == 'POST':
        sid = int(request.POST.get('txtid',0))
        stu = Student.objects.get(id= sid)
        allp = stu.paymentdetails_set.all()
        d1 = {'payments':allp,'stu':stu}
        resp = render(request,'SMS/index.html', context=d1)
        return resp
    
def get_course_wise_student_details(request):
    c=Course.objects.all()
    d1={'courses':c}
    if request.method=='GET':
        c=Course.objects.get(id=1)
        d1['cid']=c.id
        d1['cname']=c.name
        allstu=c.students.all()
        d1['students']=allstu
        resp=render(request,'SMS/course.html',context=d1)
        return resp
    elif request.method=='POST':
        course_id=int(request.POST.get('courses',0))
        c=Course.objects.get(id=course_id)
        d1['cid']=c.id  
        d1['cname']=c.name
        allstu=c.students.all()
        d1['students']=allstu
        resp=render(request,'SMS/course.html',context=d1)
        return resp
    
def view_student(request):
    if request.method == 'GET':
        frm_unbound = StudentForm()
        d1 = {'forms': frm_unbound}
        resp = render(request, 'SMS/stufrm.html', context= d1)
        return resp
    elif request.method == 'POST':
        frm_bound = StudentForm(request.Post)
        if frm_bound.is_valid():    # server side validation
            frm_bound.save()
            return HttpResponse("<h1>Student Added Successfully!!</h1>")
        else:
            d1 = {'forms':frm_bound}
            resp = render(request,'SMS/stufrm.html',context=d1)
            return resp
        
def view_paymentdetails(request):
    if request.method == 'GET':
        frm_unbound = PaymentDetailsForm()
        d1 = {'payment':frm_unbound}
        resp = render(request,'SMS/paymentfrm.html',context=d1)
        return resp
    elif request.method == 'POST':
        frm_bound = PaymentDetailsForm(request.Post)
        if frm_bound.is_valid():    # server side validation
            frm_bound.save()
            return HttpResponse("<h1>Payment Added Successfully!!</h1>")
        else:
            d1 = {'payment':frm_bound}
            resp = render(request,'SMS/paymentfrm.html',context=d1)
            return resp
        
        
        