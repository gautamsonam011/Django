from django.urls import path
from .views import *
#Base URL =>> http://127.0.0.1:8000/cms/

urlpatterns = [
    path('home/',home_cms),
    path('index/',view_index),
    path('about/',view_about),
    path('dtl/',view_dtl),
    path('customer/',view_cms),
    path('ems/',views_ems),
]
