from django.shortcuts import render
from django.http import HttpResponse
from CMS.models import *
# Create your views here.

def home_cms(request):
    resp = HttpResponse("<h1>Welcome To CMS</h1>")
    return resp
def view_index(request):
    resp = render(request, "CMS/index.html")
    return resp
def view_about(request):
    resp = render(request, "CMS/about.html")
    return resp
# Loop 
def Number(n):
    nl = []
    for i in range(1,n+1):
        nl.append(i)
    return nl
def Num(n1):
    n_list = []
    for i in range(n1,0,-1):
        n_list.append(i)
    return n_list

class Employees():
    def __init__(self):
        self.name = ""
        self.age = 0
        self.address = ""
def getNEmployee(n):
    list_emp = []
    for i in range(1,n+1):
        emps = Employees()
        emps.name = "Pankaj"+str(i)
        emps.age = 19+i
        emps.address = "New Ashok Nagar"+str(i)
        list_emp.append(emps)
    return list_emp

def view_dtl(request):
    res = Number(10)
    result = Num(20)
    employees = getNEmployee(10)
    d1 = {'x':500, 'a':400,'b':800,'c':200,'res':res,'result':result,'employees':employees}
    resp = render(request, "CMS/dtl.html", context=d1)
    return resp

def view_cms(request):
    if request.method == 'GET':
        resp = render(request, 'CMS/cms.html')
        return resp
    elif request.method == 'POST':
        if 'btnadd' in request.POST:
            cus = Customer()
            cus.name = request.POST.get('txtname','NA')
            cus.age = request.POST.get('txtage','NA')
            cus.mobileno = request.POST.get('txtno','NA')
            cus.address = request.POST.get('txtaddress','NA')
            cus.save()
            resp = HttpResponse("<h1>Customer Add Successfully in Table With ID:"+str(cus.id)+"!</h1>")
            return resp
        elif 'btnsearch' in request.POST:
            cid = int(request.POST.get("txtid",0))
            cus = Customer.objects.get(id = cid)
            d1 = {'cus':cus}
            resp = render(request,"CMS/cms.html",context=d1)
            return resp
        elif 'btnupdate' in request.POST:
            cus = Customer()
            cus.id = int(request.POST.get('txtid',0))
            if Customer.objects.get(id = cus.id):
                cus.name = request.POST.get('txtname','NA')
                cus.age = request.POST.get('txtage','NA')
                cus.mobileno = request.POST.get('txtno','NA')
                cus.address = request.POST.get('txtaddress','NA')
                cus.save()
                resp = HttpResponse("<h1>Customer Update Successfully in Table With ID:"+str(cus.id)+"!</h1>")
                return resp
        elif 'btndelete' in request.POST:
            cus_id = int(request.POST.get('txtid',0))
            Customer.objects.filter(id = cus_id).delete()
            resp = HttpResponse("<h1>Customer Delete Successfully in Table With ID:"+str(cus_id)+"!</h1>")
            return resp 
        elif 'btnshow' in request.POST:
            all_cus = Customer.objects.all()
            d1 = {'customers':all_cus}
            resp = render(request,"CMS/cms.html", context=d1)
            return resp
                    
def views_ems(request):
    if request.method == 'GET':
        resp = render(request,"CMS/ems.html")
        return resp
    elif request.method == 'POST':
        if 'btnadd' in request.POST:
            emp = Employee()
            emp.name = request.POST.get('txtname','NA')
            emp.age = request.POST.get('txtage','NA')
            emp.address = request.POST.get('txtaddress','NA')
            emp.salary = request.POST.get('txtsalary','NA')
            emp.post = request.POST.get('txtpst','NA')
            emp.save()
            resp = HttpResponse("<h1>Employee Add Successfully in Table With ID:"+str(emp.id)+"!</h1>")
            return resp
        elif 'btnsearch' in request.POST:
            cid = int(request.POST.get("txtid",0))
            emp = Employee.objects.get(id = cid)
            d1 = {'emp':emp}
            resp = render(request,"CMS/ems.html",context=d1)
            return resp
        elif 'btnupdate' in request.POST:
            emp = Employee()
            emp.id = int(request.POST.get('txtid',0))
            if Employee.objects.get(id = emp.id):
                emp.name = request.POST.get('txtname','NA')
                emp.age = request.POST.get('txtage','NA')
                emp.address = request.POST.get('txtaddress','NA')
                emp.salary = request.POST.get('txtsalary','NA')
                emp.post = request.POST.get('txtpst','NA')
                emp.save()
                resp = HttpResponse("<h1>Employee Update Successfully in Table With ID:"+str(emp.id)+"!</h1>")
                return resp
        elif 'btndelete' in request.POST:
            emp_id = int(request.POST.get('txtid',0))
            Employee.objects.filter(id = emp_id).delete()
            resp = HttpResponse("<h1>Employee Delete Successfully in Table With ID:"+str(emp_id)+"!</h1>")
            return resp 
        elif 'btnshow' in request.POST:
            all_emp = Employee.objects.all()
            d1 = {'employees':all_emp}
            resp = render(request,"CMS/ems.html", context=d1)
            return resp           
    